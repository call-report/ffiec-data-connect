ffiec\_data\_connect package
============================

Submodules
----------

ffiec\_data\_connect.constants module
-------------------------------------

.. automodule:: ffiec_data_connect.constants
   :members:
   :undoc-members:
   :show-inheritance:

ffiec\_data\_connect.credentials module
---------------------------------------

.. automodule:: ffiec_data_connect.credentials
   :members:
   :undoc-members:
   :show-inheritance:

ffiec\_data\_connect.datahelpers module
---------------------------------------

.. automodule:: ffiec_data_connect.datahelpers
   :members:
   :undoc-members:
   :show-inheritance:

ffiec\_data\_connect.exceptions module
--------------------------------------

.. automodule:: ffiec_data_connect.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

ffiec\_data\_connect.ffiec\_connection module
---------------------------------------------

.. automodule:: ffiec_data_connect.ffiec_connection
   :members:
   :undoc-members:
   :show-inheritance:

ffiec\_data\_connect.methods module
-----------------------------------

.. automodule:: ffiec_data_connect.methods
   :members:
   :undoc-members:
   :show-inheritance:

ffiec\_data\_connect.xbrl\_processor module
-------------------------------------------

.. automodule:: ffiec_data_connect.xbrl_processor
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ffiec_data_connect
   :members:
   :undoc-members:
   :show-inheritance:
