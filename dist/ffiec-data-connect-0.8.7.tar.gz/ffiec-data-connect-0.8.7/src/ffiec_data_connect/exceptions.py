"""Descriptive exceptions for the ffiec_data_connect package
"""

class NoDataError(Exception):
    pass

